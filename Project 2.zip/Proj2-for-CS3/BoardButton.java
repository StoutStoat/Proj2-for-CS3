import mayflower.*;

public class BoardButton extends Actor{
	public BoardButton()
	{
		setImage("images/highScore.png");
	}
	public void act()
	{
		
	}
}
