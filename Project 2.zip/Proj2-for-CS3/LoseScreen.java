import mayflower.*;
public class LoseScreen extends WorldManager{
    public LoseScreen()
    {
        switchWorld("lose");
    }
    public void act() 
    {
        super.act();
    }
}
