import mayflower.*;
/**
 * This was made just to manage all the other worlds.
 * And was also made at 0130 in the morning to meet the rubric lmao.
 * 
 * This class streamlines the process of switching the worlds.
 * I.E from the 'table' to the lose or win screen and all that jazz.
 */
public class WorldManager extends World
{
    private MenuButton menu = new MenuButton();
    //FORCES LOSS
    private QuitGame quit = new QuitGame();
    private HitButton hit = new HitButton();
    private StandButton stand = new StandButton();
    private DeckButton deck = new DeckButton();
    //CLOSES APPLICATION
    private ExitGameButton exit = new ExitGameButton();
    private BoardButton board = new BoardButton();
    private StartGame start = new StartGame();
    private int returnBoard = LeaderBoard.returnBoard();
    
    public static int total = 0;
    public static int winCount = 0;
    private int toBeat = (int) ((Math.random() * 5) + 15 );
    
    private int defX = 500;
    
    private cardDeck cd;
    /**
     * 1 simple parameter to see what world is to be switched to.
     */
    public void switchWorld(String world)
    {
        if(world.equals("table"))
        {
            total = 0;
            cd = new cardDeck();
            cd.createDeck();
            setBackground("images/background.jpeg");
            addObject(quit, 10, 10);
            addObject(stand, 1400, 100);
            addObject(hit, 100, 100);
            addObject(deck, 500, 500);
            showText("Beat " + toBeat + " to win!", 1000, 1000);
            showText("Total: " + total, 700, 1000);
            showText("Win Streak : " + winCount, 100, 500);
        }
        else if(world.equals("win"))
        {
            setBackground("images/WinScreen.png");
            addObject(menu, 1200, 400);
            addObject(start, 500, 400);
            gameBoard.winCount++;            
        }
        else if(world.equals("lose"))
        {
            setBackground("images/ExampleGameOver.png");
            addObject(menu, 400, 700);
            addObject(exit, 1200, 700);
            addObject(board, 800, 700);
            Mayflower.playMusic("sounds/Lost.wav");
            LeaderBoard.addScore(String.valueOf(gameBoard.winCount));
            gameBoard.winCount = 0;
        }
        else if(world.equals("scores"))
        {
            setBackground("images/background.jpeg");
            addObject(menu, 100, 100);
            showText("Highest Score : " + returnBoard, 1000, 700);
        }
    }
    public void setTotal(int num)
    {
        total += num;
    }
    /**
     * Button setups. For our clicking pleasure.
     * Remember to put super.act() in the act method when inheriting from this class.
     * Although I doubt anyone is stupid enough to work with this horrible thing as a framework.
     */
    public void act()
    {
        if (Mayflower.mousePressed(menu) == true)
        {   
            gameBoard.total = 0;
            Mayflower.setWorld(new titleScreen());
        }        
        if (Mayflower.mousePressed(start) == true)
        {    
            Mayflower.setWorld(new gameBoard());
        }
        if (Mayflower.mousePressed(exit))
        {
            Mayflower.exit();
        }
        if(Mayflower.mousePressed(board))
        {
            Mayflower.playSound("sounds/Stand.wav");
            Mayflower.setWorld(new Board());
        }
        if (Mayflower.mousePressed(quit) == true)
        {    
            Mayflower.playSound("sounds/Lost.wav");
            Mayflower.setWorld(new LoseScreen());
        }
        if (Mayflower.mousePressed(hit))
        {
            Mayflower.playSound("sounds/Hit.wav");            
            Card c = new Card(cd);
            setTotal(c.getNumber());
            addObject(c, defX, 1000);
            defX += 30;
            showText("Total: " + total, 700, 1000);
        }
        if (Mayflower.mousePressed(stand))
        {
            Mayflower.playSound("sounds/Stand.wav");
            if (total > 21 || total <= toBeat)
            {
                Mayflower.playSound("sounds/Lost.wav");
                Mayflower.setWorld(new LoseScreen());
            }
            else
            {
                Mayflower.playSound("sounds/Win.wav");
                Mayflower.setWorld(new WinScreen());
            }
        }
    }
}
