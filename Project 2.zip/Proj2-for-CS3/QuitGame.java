import mayflower.*;

/**
 * @author StoutStoat
 * A simple actor to serve as a button.
 * 
 */
public class QuitGame extends Actor{
	public QuitGame()
	{
		setImage("images/QuitButton.png");
	}
	public void act() 
	{

	}
}
