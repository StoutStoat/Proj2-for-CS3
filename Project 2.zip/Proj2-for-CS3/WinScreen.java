import mayflower.*;

public class WinScreen extends WorldManager{
    MenuButton menu = new MenuButton();
    StartGame start = new StartGame();
    public WinScreen()
    {
        switchWorld("win");
    }
    public void act()
    { 
        super.act();
    }
}
