# Proj2
Blackjack but like worse.
For Computer Science 3 project :3

Mayflower Documentation:
https://drive.google.com/drive/folders/1w_ojUgOA5_Re-pXoDlCjWSRbjXLAIayt 

Install Visual Studio Code & relavent github extensions ofc

<h2>JAVA DOCUMENTATION TERMS</h2>

![image](https://github.com/user-attachments/assets/47382642-885c-4b5c-b87a-806708106ac8)


LiveShare Link ;
