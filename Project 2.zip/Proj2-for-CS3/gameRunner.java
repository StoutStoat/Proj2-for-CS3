public class gameRunner{ 
    public static void main(String[] args)
    {
        new TheNewWorld();
    }
}
