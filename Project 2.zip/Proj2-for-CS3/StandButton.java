import mayflower.*;

public class StandButton extends Actor{
	public StandButton()
	{
		setImage("images/StandButton.png");
	}
	public void act()
	{
		
	}
}
