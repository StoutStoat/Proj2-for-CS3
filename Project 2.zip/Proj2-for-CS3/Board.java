import mayflower.*;
public class Board extends WorldManager
{
    MenuButton menu = new MenuButton();
    int returnBoard = LeaderBoard.returnBoard();
    public Board()
    {
        switchWorld("scores");
    }
    public void act()
    {   
        super.act();
    }
}
