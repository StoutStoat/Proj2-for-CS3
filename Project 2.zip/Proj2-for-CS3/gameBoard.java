import mayflower.*;
/**
Created: 4/10/2025 (DD/MM/YYYY)
Creates the game board
Will switch to win or lose screens if conditions are met.
*/
public class gameBoard extends WorldManager
{
    public gameBoard()
    {
        switchWorld("table");
    }
    public void act()
    {
        super.act();
    }
}