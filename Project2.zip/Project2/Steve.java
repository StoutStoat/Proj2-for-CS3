import mayflower.*;
public class Steve extends Actor{
	public Steve()
	{
		setImage("images/IAmSteve.jpg");
	}
	public void act()
	{
		
	}
}
