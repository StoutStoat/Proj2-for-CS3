import mayflower.*;
public class DeckButton extends Actor {
	public DeckButton()
	{
		setImage("images/DeckImage.jpg");
	}
	public void act()
	{
		
	}
}

