import mayflower.*;

/**
 * @author StoutStoat
 * A simple actor to serve as a button.
 * 
 */
public class ExitGameButton extends Actor{
	public ExitGameButton()
	{
		setImage("images/quit.png");
		
	}
	public void act() 
	{
		
		
	}
}
