import mayflower.*;

/**
 * @author StoutStoat
 * A simple actor to serve as a button.
 * 
 */
public class MenuButton extends Actor{
	public MenuButton()
	{
		setImage("images/Menu.png");
	}
	public void act() 
	{

	}
}
