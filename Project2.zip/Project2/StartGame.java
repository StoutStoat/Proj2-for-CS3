import mayflower.*;

/**
 * @author StoutStoat
 * A simple actor to serve as a button.
 * 
 */
public class StartGame extends Actor{
	public StartGame()
	{
		setImage("images/Start.png");
	}
	public void act() 
	{

	}
}
