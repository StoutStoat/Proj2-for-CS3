import mayflower.*;

/**
 * 
 */
public class HitButton extends Actor{
	public HitButton()
	{
		setImage("images/HitButton.png");
	}
	public void act()
	{
		
	}
}
